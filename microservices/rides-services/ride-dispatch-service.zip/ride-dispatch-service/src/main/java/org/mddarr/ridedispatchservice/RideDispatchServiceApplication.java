package org.mddarr.ridedispatchservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RideDispatchServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RideDispatchServiceApplication.class, args);
	}

}
